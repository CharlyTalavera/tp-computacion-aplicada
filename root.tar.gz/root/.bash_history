ifup enp0s1 
vi /etc/network/interfaces
cd /home/entregables/tp-computacion-aplicada/
ls
./compress_files.sh 
shutdown -h now
ls
cd /home/entregables/tp-computacion-aplicada/
ls
htop
git status
git add etc.tar.gz root.tar.gz var.tar.gz.part.a*
git status
git commit -m "agrego resolucion de puntos 2 (servicios) y 3 (configuracion de red)"
git push origin master
git push origin master
git push origin master
ls
clear
ls
lsblk -l
vi /etc/fstab 
lsblk
vi /etc/fstab 
fsdisk /sda
fdisk /sda
fdisk /dev/sda
lsblk
lsblk
fdisk -l /dev/sda
fdisk /dev/sda
lbslk
lbslk
lsblk
fdisk /dev/sda
fdisk /dev/sda
lsblk
fdisk /dev/sda
lsblk
fdisk /dev/sda
lsblk
fdisk /dev/sda
lsblk
fdisk -l /dev/sda
mks -t ext4 /dev/sda1 
mkfs -t ext4 /dev/sda1 
mkfs -t ext4 /dev/sda2
cd /
ls
mkdir /www_dir
mkdir /backup_dir
vi /etc/fstab 
reboot
lsblk
cd /etc/apache2/
ls
cd sites-available/
ls
cd ..
cd /var/www/html/
ls
mv index.php /www_dir/
mv logo.png /www_dir/
ls
cdc /www_dir/
ls
cd /www_dir/
ls
cd
cd /etc/apache2/
ls
cd conf-available/
ls
cd ..
ls
cd sites-available/
ls
pwd
vi 000-default.conf 
vi 000-default.conf 
ls
cd ..
ls
vi apache2.conf 
pwd
vi apache2.conf 
sudo systemctl restart apache2

ls -l /www_dir
chmod 777 /www_dir
ls -l /www_dir
ls -l /
sudo systemctl restart apache2
vi apache2.conf 
sudo systemctl restart apache2
ls
vi sites-available/000-default.conf 
cd /www_dir/
ls
vi index.php 
sudo systemctl restart apache2
vi index.php 
vi index.php 
sudo systemctl restart apache2
vi index.php 
vi index.php 
cd /home/entregables/tp-computacion-aplicada/
ls
vi compress_files.sh 
vi compress_files.sh 
vi compress_files.sh 
git status
git diff compress_files.sh
git add compress_files.sh 
git status
git commit -m "compress www_dir and backup_dir" folders
git commit -m "compress www_dir and backup_dir folders"
gst 
git status
./compress_files.sh 
cat compress_files.sh 
vi compress_files.sh 
vi compress_files.sh 
./compress_files.sh 
vi compress_files.sh 
./compress_files.sh 
git status
git add compress_files.sh 
git commit -m "update compress file script"
git status
git add .
git status
git commit -m "agrego www_dir and backup_dir; finalizando tarea nº5"
git status
git push origin master
git pull origin master
git push origin master
cd
cd /opt/
ls
mkdir scripts
ls
cd scripts/
ls
vi backup_full.sh
chmod +x backup_full.sh 
./backup_full.sh 
./backup_full.sh 
./backup_full.sh  hola
./backup_full.sh hola
./backup_full.sh hola
./backup_full.sh 
./backup_full.sh 
./backup_full.sh 
./backup_full.sh 
./backup_full.sh -help
./backup_full.sh -help
./backup_full.sh 
./backup_full.sh 
./backup_full.sh 
./backup_full.sh test test
./backup_full.sh test test
./backup_full.sh /var/log/
./backup_full.sh /var/log /tmp/
./backup_full.sh /var/log /tmp/asdadas
./backup_full.sh /var/log /tmp/asdadas
./backup_full.sh /var/log /tmp/asdadas
./backup_full.sh /var/asdas
./backup_full.sh /var/asdas asdas
./backup_full.sh /var/asdas asdas
./backup_full.sh /var/log /tmp/asdadas
./backup_full.sh /var/log /tmp
./backup_full.sh /var/log /tmp
./backup_full.sh /var/log /tmp
./backup_full.sh /var/mail /tmp
cat /etc/fstab 
./backup_full.sh /var/mail /tmp
./backup_full.sh 
cat /home/entregables/tp-computacion-aplicada/compress_files.sh 
./backup_full.sh /var/log /tmp
ls /tmp/
tar xvzf /tmp/log_bkp_20250521.tar.gz 
ls
rm -rf var
ls
./backup_full.sh /var/log /tmp
ls
ll
ls -l
cd /home/entregables/tp-computacion-aplicada/
ls
vi compress_files.sh 
gst 
git status
cat compress_files.sh 
tar -czf opt.tar.gz /opt
git status
git add opt.tar.gz 
git status
git commit -m "Agrego script de tarea nº5: Backup"
git push origin master
git pull origin master
git push origin master
cd /opt/
ls
cd scripts/
ls
vi backup_full.sh 
vi backup_full.sh 
clear
ls
exit
ls
clear
ls
clear
ls
exit
ls
cd /home/entregables/tp-computacion-aplicada/
ls
git status
git branch
git fetch origin
exit
lsblk
vi /etc/fstab 
gst 
ls
clear
ls
ifconfig -a
ip a
clear
ip a
wget
ssh hackstation@192.168.1.41
exit
ls
ls
sudo shutdown -h now
ls
clear
ls
pwd
ls
contab -e
crontab -e
grep CRON /var/log/syslog
tail -f CRON /var/log/syslog
tail -f /var/log/syslog | grep CRON
crontab -e
tail -f /var/log/syslog | grep CRON
crontab -e
gst 
gst 
cat /var/spool/cron/crontabs/root 
cd /home/entregables/tp-computacion-aplicada/
ls
git status
git checkout tmp/charly
git pull origin tmp/charly
./compress_files.sh 
git status
git add .
git status
git commit -m "terminando punto 5"
git status
git push origin tmp/charly 
clear
git status
ls
ls
ls -a
cd /rrot
cd /rrot
cd /root
ls
ls
cd /rrot
cd /root
ls
cd /www_dir/
ls
cd backup_dir/
ls
cd ..
ls
cd ..
ls
cd /backup_dir/
ls
ls
cd .
cd ..
ls
ls
clear
ls
exit
cd /root/
ls
ls
ls
ls
cd ..
ls
ls
ls
sudo tcpdump -y any port 22
apt install tcpdump
sudo tcpdump -y any port 22
sudo tcpdump -i any port 22
systemctl status ssh
systemctl start ssh
systemctl status ssh
sudo systemctl start ssh
systemctl status ssh
exit
journalctl -xb
lsblk -l
cat /etc/fstab 
lsblk -l
cat /www_dir/
ls
ls /www_dir/
ls /www_dir/
ls /www_dir/www_dir/
ls
ls
cd /
ls
cd www_dir/
ls
cd home/
ls
cd ..
ls
cd
ls
ls
cd /etc/fstab 
micro /etc/fstab 
vi /etc/fstab 
ls
cd /
ls -a
cd www_dir/
ls
cd ..
exit
ls
cd /
ls
cd www_dir/
ls
cd .
cd 
ls
lsblk -l
poweroff
ls
exit
ls
sudo systemctl status
ls
clear
shutdown -h 
shutdown -h now
ls
ip -a
ip a
cat /etc/network/interfaces
shutdown -h now
lsblk
cd /etc
cat fstab 
shutdown -h now
cd /etc
cat fstab 
lsblk -l
lsblk -f
ls
lsblk -l
lsblk -f
vi /etc/fstab 
vi /etc/fstab 
vi /etc/fstab 
reboot
ldblk -l
lsblk -l
shutdown -h now
vi /etc/fstab 
shutdown -h now
ls
exit
ls
exit
ls
crontab -e
clear
cd /etc/network/
ls
vi interfaces
sudo systemctl restart ssh
sudo systemctl status ssh
sudo systemctl status ssh
ssh root@192.168.1.64
sudo systemctl status ssh
vi interfaces
ifdown enp0s1 
ifconfig -a
ifdown enp0s1
sudo ifdown enp0s1
vi /etc/networks/interfaces
sudo vi /etc/networks/interfaces
vi /etc/network/interfaces
ip a
ifup enp0s1
ip a
sudo systemctl restart ssh
sudo systemctl status  ssh
sudo systemctl status  ssh
ssh root@192.168.1.64
ls
cat /etc/ssh/sshd_config
cat /etc/ssh/sshd_config | less
sudo netstat -tlnp | grep :22
cd /etc/
ls
cat host.allow
cat hosts.allow
cat hosts.deny
ip a
ifconfig
vi /etc/network/interfaces
systemctl status ssh
systemctl restart ssh
ssh localhost
sudo iptables -L -n -v | grep 22
shutdown -h now
crontab -e
cat /proc/partitions 
ls
exit
clear
exit
crontab -e
ls
cat /etc/network/interfaces
ls
cd /home/
ls
clear
ls
clear
ls
clear
ls
exit
exit
cd /home/
ls
cd
vi /etc/fstab 
shutdown -h now
curl ifconfig.me
clear
ip a
systemctl status ssh
ls
systemctl status
systemctl status ssh
systemctl status ssh
systemctl status ssh
journalctl -u sshd --since "5 minutes ago"
cd /home/
ls
cd entregables/
ls
cd
ls
systemctl status sshd
ls
ping 192.168.1.64
systemctl restart sshd
systemctl status sshd
ip a
shutdown -h now
ls
cd /home/
ls
cd
crontab -e
cat /opt/particion 
cd /home/entregables/
ls
cd tp-computacion-aplicada/
ls
exit
