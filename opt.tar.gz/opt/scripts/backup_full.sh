#!/bin/bash

printHelp(){
	echo "Usage examples:"
	echo "• backup_full /var/log /tmp"
	echo "• backup_full.sh /etc/ /root"
}

if [ "$1" == "-help" ]; then
	printHelp
	exit 0
fi

if [ "$#" -ne 2 ]; then
	echo "Invalid number or arguments. Expected 2 arguments"
	printHelp
	exit 1
fi

origin=$1
dest=$2

if [ ! -d $origin ]; then
	echo "Origin path $origin not found."
	exit 2
fi

if [ ! -d $dest ]; then
	echo "Destination path $dest not found."
	exit 3
fi

filename=$(basename $origin)
datetime=$(date +%Y%m%d)
result_name="${filename}_bkp_${datetime}.tar.gz"

echo "Compressing ${origin} -> ${dest}/${result_name}..."
tar -czf "${dest}/${result_name}" $origin 
echo "Success"
