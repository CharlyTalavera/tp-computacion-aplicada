#!/bin/bash

fecha=$(date +%Y%m%d)

function help() {
  echo "Uso: $0 origen destino"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
}

if [[ "$1" == "-help" ]]; then
  help
fi

if [[ $# -ne 2 ]]; then
  echo "Error: se requieren 2 parámetros"
  help
fi

if [[ ! -d "$1" ]] || [[ ! -d "$2" ]]; then
  echo "Error: origen o destino no existen"
  exit 1
fi

origen="$1"
destino="$2"
nombre=$(basename "$origen")_bkp_${fecha}.tar.gz

tar -czf "$destino/$nombre" "$origen"

